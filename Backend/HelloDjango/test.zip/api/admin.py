from django.contrib import admin


admin.site.site_title = 'CvetoGIS'
admin.site.site_header = 'CvetoGIS - администрирование'